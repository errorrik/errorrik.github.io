er.template.parse('<!--target:auto-->hello auto');

myModule.auto = new er.Action({
    view: 'auto'
});
