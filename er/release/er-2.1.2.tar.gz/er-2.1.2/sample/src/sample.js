/*
 * ER Sample
 * 
 * path:    src/sample.js
 * desc:    初始化
 * author:  erik
 */


er.config.TEMPLATE_LIST = [
    'src/user/list.html'
];

window.onload = function () {
    er.init();
};
