/*
 * ER Sample
 * 
 * path:    src/user/model.js
 * desc:    model包声明
 * author:  erik
 */


user.model = {};
