/* 建议 */
/* debug时，使用document.write的方法引入外部css */
/* 上线前或提交测试前，使用shell合并 */

document.write( '<script src="../release/er-2.1.2.js" type="text/javascript"></script>' );  


document.write( '<script src="../release/esui-2.1.2.js" type="text/javascript"></script>' );  

