/*
 * ESUI (Enterprise Simple UI)
 * Copyright 2010 Baidu Inc. All rights reserved.
 * 
 * path:    esui.js
 * desc:    esui是一套简单的WEB UI库
 * author:  erik
 */

var esui = {};
