/*
 * ESUI (Enterprise Simple UI)
 * Copyright 2010 Baidu Inc. All rights reserved.
 * 
 * path:    esui/validator.js
 * desc:    声明validator
 * author:  erik
 */

///import esui;


esui.validator = {};
