/*
 * ESUI (Enterprise Simple UI)
 * Copyright 2010 Baidu Inc. All rights reserved.
 * 
 * path:    esui/config.js
 * desc:    ui控件配置项
 * author:  erik
 */


esui.config = {
    UI_ATTRIBUTE: 'ui'
};

