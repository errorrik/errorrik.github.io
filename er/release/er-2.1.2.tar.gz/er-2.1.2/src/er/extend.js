/*
 * ER (Enterprise RIA)
 * Copyright 2010 Baidu Inc. All rights reserved.
 * 
 * path:    er/extend.js
 * desc:    扩展包容器声明
 * author:  erik
 */


er.extend = {};
